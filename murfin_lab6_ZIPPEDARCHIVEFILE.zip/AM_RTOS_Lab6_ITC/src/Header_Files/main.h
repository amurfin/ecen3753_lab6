//***********************************************************************************
// Include files
//***********************************************************************************

#include <stdint.h>
#include <stdbool.h>

//***********************************************************************************
// defined files
//***********************************************************************************
#define LAB2_USE_INTERRUPT true
#define	INFINITE_LOOP		true

// Micrium OS Defines
#define  EX_MAIN_START_TASK_PRIO		21u
#define  EX_MAIN_START_TASK_STK_SIZE    512u
#define  EX_BUTTON_INPUT_TASK_PRIO      2u
#define  EX_BUTTON_INPUT_TASK_STK_SIZE  512u
#define  EX_SLIDER_INPUT_TASK_PRIO      1u
#define  EX_SLIDER_INPUT_TASK_STK_SIZE  512u
#define  EX_LED_OUTPUT_TASK_PRIO       	3u
#define  EX_LED_OUTPUT_TASK_STK_SIZE    512u
#define	 EX_BUTTON_INPUT_TASK_DELAY		100u
#define	 EX_SLIDER_INPUT_TASK_DELAY		100u
#define	 EX_LED_OUTPUT_TASK_DELAY		100u
#define  EX_LED_OUTPUT_MSGQ_MAX_SIZE	256u
#define  EX_IDLE_TASK_STK_SIZE			64u
#define  EX_IDLE_TASK_PRIO				22u

// Message Queue - Message Bytes
// Bytes Sent from both ButtonInput and SliderInput tasks follow same structure
//
// Bit	4					3				2				1				0
//		0=slider, 1=button	slider left		slider right	btn1			btn0
#define EX_MSGQ_MSGTYPE_MASK		0x10
#define EX_MSGQ_SLIDER_MASK			0xC
#define	EX_MSGQ_BUTTON_MASK			0x3
#define EX_MSGQ_SLIDER_BASE			0x0
#define EX_MSGQ_BUTTON_BASE			0x10

	// all variables true if user asserted, else false
	// LED output task concatenates these bits into a byte for processing as described below
	/*
	 * All bits true when asserted by user, false otherwise
	 *
	 * Bit: 3				2				1			0
	 *		Slider Left		Slider Right	Btn1		Btn0
	 *
	 * States:
	 * Nothing Set 	== 0x0 -> LED0 OFF 	LED1 OFF
	 * Btn0 Only 	== 0x1 -> LED0 ON 	LED1 OFF
	 * Btn1 Only 	== 0x2 -> LED0 OFF 	LED1 ON
	 * Both Buttons == 0x3 -> LED0 OFF 	LED1 OFF
	 * Slider Right == 0x4 -> LED0 OFF 	LED1 ON
	 * SRight+Btn0  == 0x5 -> LED0 ON	LED1 ON
	 * Sright+Btn1  == 0x6 -> LED0 OFF  LED1 ON
	 * Sright+Btn1,0== 0x7 -> LED0 OFF 	LED1 ON
	 * Slider Left  == 0x8 -> LED0 ON 	LED1 OFF
	 * Sleft+Btn0   == 0x9 -> LED0 ON 	LED1 OFF
	 * Sleft+Btn1	== 0xA -> LED0 ON	LED1 ON
	 * Sleft+Btn0,1 == 0xB -> LED0 ON 	LED1 OFF
	 * Sleft+Sright == 0xC -> LED0 OFF	LED1 OFF
	 * 			   0xD-0xF -> LED0 OFF  LED1 OFF
	 */
// defines for LED output state byte (ledOutputState in Ex_LEDOutputTask())
#define NOTHING_SET			0x0
#define BTN0_SET			0x1
#define BTN1_SET			0x2
#define	BOTH_BTN_SET		0x3
#define SRIGHT_SET			0x4
#define SRIGHT_BTN0_SET		0x5
#define SRIGHT_BTN1_SET		0x6
#define SRIGHT_BOTH_BTN_SET	0x7
#define SLEFT_SET			0x8
#define SLEFT_BTN0_SET		0x9
#define SLEFT_BTN1_SET		0xA
#define	SLEFT_BOTH_BTN_SET	0xB
#define SLEFT_SRIGHT_SET	0xC

// btn0 and btn1 event flags
// bit		1						0
//			Button 1 changed state	button 0 changed state



//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************
void postFlagToEvent(uint8_t buttons);
